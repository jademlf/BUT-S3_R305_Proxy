// Jade BEAUJOUR
// Denisa RIPICEANU
// S3 - E

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include "./simpleSocketAPI.h"


#define SERVADDR "127.0.0.1"        // Définition de l'adresse IP d'écoute
#define SERVPORT "0"                // Définition du port d'écoute, si 0 port choisi dynamiquement
#define LISTENLEN 1                 // Taille de la file des demandes de connexion
#define MAXBUFFERLEN 1024           // Taille du tampon pour les échanges de données
#define MAXHOSTLEN 64               // Taille d'un nom de machine
#define MAXPORTLEN 64               // Taille d'un numéro de port


void extraireInfosClient(char buffer[], char* adresse, char* port);
void gestionnaireConnexionsMultiples(int descSockCOM, const char *serverAddr);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(){
    int ecode;                       // Code retour des fonctions
    char serverAddr[MAXHOSTLEN];     // Adresse du serveur
    char serverPort[MAXPORTLEN];     // Port du server
    int descSockRDV;                 // Descripteur de socket de rendez-vous qui écoute les connexions entrantes
    int descSockCOM;                 // Descripteur de socket de communication qui est créé pour chaque connexion entrante acceptée à partir de la socket de rendez-vous
    struct addrinfo hints;           // Contrôle la fonction getaddrinfo
    struct addrinfo *res;            // Contient le résultat de la fonction getaddrinfo
    struct sockaddr_storage myinfo;  // Informations sur la connexion de RDV
    struct sockaddr_storage from;    // Informations sur le client connecté
    socklen_t len;                   // Variable utilisée pour stocker les longueurs des structures de socket
    char buffer[MAXBUFFERLEN];       // Tampon de communication entre le client et le serveur

    // Initialisation de la socket de RDV IPv4(AF_INET)/TCP(SOCK_STREAM)
    descSockRDV = socket(AF_INET, SOCK_STREAM, 0);
    if (descSockRDV == -1) {
         perror("Erreur création socket RDV\n");
         exit(2);
    }
    // Publication de la socket au niveau du système et assignation d'une adresse IP et un numéro de port;
    memset(&hints, 0, sizeof(hints));

    // Initialisation de hints
    hints.ai_flags = AI_PASSIVE;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_family = AF_INET;

     ecode = getaddrinfo(SERVADDR, SERVPORT, &hints, &res);  // Appelle la fonction getaddrinfo pour obtenir des informations sur l'adresse du serveur
     if (ecode) {
         fprintf(stderr,"getaddrinfo: %s\n", gai_strerror(ecode));
         exit(1);
     }
     // Publication de la socket
     ecode = bind(descSockRDV, res->ai_addr, res->ai_addrlen); // fonction bind pour lier la socket descSockRDV à une adresse et un port
     if (ecode == -1) {
         perror("Erreur liaison de la socket de RDV");
         exit(3);
     }
     freeaddrinfo(res); // supression de la liste pour libérer la mémoire
     len = sizeof(struct sockaddr_storage); // Récuppération du nom de la machine et du numéro de port associés à descSockRDV

     ecode = getsockname(descSockRDV, (struct sockaddr *) &myinfo, &len); // obtenir les informations sur l'adresse associée à la socket descSockRDV
     if (ecode == -1){
         perror("SERVEUR: getsockname");
         exit(4);
     }

     ecode = getnameinfo((struct sockaddr*)&myinfo, sizeof(myinfo), serverAddr,MAXHOSTLEN,
                         serverPort, MAXPORTLEN, NI_NUMERICHOST | NI_NUMERICSERV); // convertir les informations sur l'adresse récupérées précédemment en noms d'hôte et numéros de port lisibles
     if (ecode != 0) {
         fprintf(stderr, "error in getnameinfo: %s\n", gai_strerror(ecode));
         exit(4);
     }
     printf("L'adresse d'ecoute est: %s\n", serverAddr); // nom d'hôte
     printf("Le port d'ecoute est: %s\n", serverPort); // numéro de port

     ecode = listen(descSockRDV, LISTENLEN); // définition taille tampon
     if (ecode == -1) {
         perror("Erreur initialisation buffer d'écoute");
         exit(5);
     }

     // initialisisation de len avec la taille de la structure qui stockera les informations sur le client après le accept
	   len = sizeof(struct sockaddr_storage);

     // Multiconnexion
     while (true) {
        descSockCOM = accept(descSockRDV, (struct sockaddr *) &from, &len);   // Lorsque demande de connexion, creation d'une socket de communication avec le client
        if (descSockCOM == -1){
            perror("Erreur accept\n");
            exit(6);
        }

        pid_t pid = fork(); // Création d'un nouveau processus fils pour gérer la communication avec le client
        if (pid == -1) {
            perror("Erreur fork\n");
            exit(7);
        } else if (pid == 0) { // Processus enfant
            close(descSockRDV); // Fermeture de la socket de rendez-vous dans le processus enfant
            gestionnaireConnexionsMultiples(descSockCOM, serverAddr); // Traitement de la communication avec le client
            close(descSockCOM); // Fermer la socket de communication dans le processus enfant
            exit(0); // Terminer le processus enfant après le traitement du client
        } else { // Processus parent
            close(descSockCOM); // Fermer la socket de communication dans le processus parent
        }
    }
    close(descSockRDV); // Fermer la socket de rendez-vous dans le processus parent
    return 0;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void extraireInfosClient(char buffer[], char* adresse, char* port) {
    // Adresse
    // Trouver la première parenthèse ouvrante
    char* debutAdresse = strchr(buffer, '(');
    // Copier le contenu après la parenthèse ouvrante dans la chaîne adresse
    strcpy(adresse, debutAdresse + 1);

    // Remplacer les virgules par des points dans l'adresse (format IPv4)
    char* virgule;
    for (int i = 0; i < 3; i++) {
        virgule = strchr(adresse, ',');
        *virgule = '.';
    }

    // Trouver la dernière virgule dans l'adresse
    char* finAdresse = strchr(adresse, ',');
    // Terminer la chaîne après la dernière virgule
    *finAdresse = '\0';


    // Port
    // Copier le contenu après la dernière virgule dans la chaîne port
    strcpy(port, finAdresse + 1);
    // Trouver la première virgule dans la chaîne port
    char* virguleMilieu = strchr(port, ',');
    // Trouver la parenthèse fermante dans la chaîne port
    char* virguleFin = strchr(port, ')');
    // Terminer la partie du port après la première virgule
    *virguleMilieu = '\0';
    // Terminer la partie du port après la parenthèse fermante
    *virguleFin = '\0';

    // Séparer les parties du port en deux variables temporaires
    char partie1[MAXPORTLEN], partie2[MAXPORTLEN];
    strcpy(partie1, port);
    strcpy(partie2, virguleMilieu + 1);

    // Calculer la valeur du port en utilisant les deux parties
    sprintf(port, "%d", atoi(partie1) * 256 + atoi(partie2));
}



// fonction gerant la communication avec un client après l'accept de sa connexion
void gestionnaireConnexionsMultiples(int descSockCOM, const char *serverAddr) {
    char buffer[MAXBUFFERLEN];  // Tampon de communication entre le client et le serveur

    strcpy(buffer, "220 Bienvenue sur le proxy de Jade BEAUJOUR et Denisa RIPICEANU\r\n");
    write(descSockCOM, buffer, strlen(buffer)); // réponse au client via la socket de communication

    // lire les données provenant du client à travers la socket de communication
    int ecode = read(descSockCOM, buffer, MAXBUFFERLEN - 1);
    if (ecode == -1) {
        perror("Erreur lors de la lecture des données provenant du client à travers la socket de communication !");
        exit(2);
    }
    buffer[ecode] = '\0';
    printf("Client : %s\n", buffer);

    // USER anonymous@ftp.fau.de
	  // récupération du login et du serveur à partir des données lues du client, puis établir une connexion à un serveur FTP
    char identifiant[30];
    sscanf(buffer, "%[^@]@%s", identifiant, serverAddr); // extrait une séquence de caractères jusqu'au @ pour le login, puis une séquence de caractères jusqu'à l'espace pour le serveur
	  printf("Votre identifiant : %s\nServeur auquel vous voulez vous connecter : %s\n", identifiant, serverAddr);

    int sockServeurCOMftp; // nouvelle socket utilisée pour la communication avec le serveur FTP
    // établir une connexion avec le serveur FTP qui écoute sur le port 21
    ecode = connect2Server(serverAddr, "21", &sockServeurCOMftp);
    if (ecode == -1){
        perror("Il y a eu une erreur de connexion au serveur FTP");
        exit(2);
    }
    printf("Vous êtes bien connecté(e) au serveur FTP\n");

    // Attente de la réponse d'accueil (code 220) du serveur FTP pour confirmer la connexion au proxy
    ecode = read(sockServeurCOMftp, buffer, MAXBUFFERLEN-1); // lire des données de la socket
    if (ecode == -1){
    	perror("Il y a eu une erreur lors de la lecture d'une socket !");
    	exit(2);
    }
    buffer[ecode] ='\0';
    printf("Serveur : %s\n", buffer);

    // le proxy envoie la commande "USER anonymous" du client et s'attend à recevoir une réponse avec le code 331 du serveur FTP
    strcpy(buffer, identifiant);
    strcat(buffer, "\r\n");

    write(sockServeurCOMftp, buffer, strlen(buffer)); // envoie de la commande "USER anonymous\r\n" au serveur FTP via la socket sockServeurCOMftp
    ecode = read(sockServeurCOMftp, buffer, MAXBUFFERLEN-1); // lire la réponse du serveur FTP depuis la socket
    if (ecode == -1){
    	perror("Il y a eu une erreur lors de la lecture d'une socket !");
    	exit(2);
    }
    buffer[ecode] = '\0';
    printf("Serveur : %s\n", buffer);

    // le proxy envoie 331 au client et s'attend à recevoir la commande PASS du client
    write(descSockCOM, buffer, strlen(buffer));
    ecode = read(descSockCOM, buffer, MAXBUFFERLEN-1); // lire la commande PASS envoyée par le client depuis la socket descSockCOM
    if (ecode == -1){
    	perror("Il y a eu une erreur lors de la lecture d'une socket !");
    	exit(2);
    }
    buffer[ecode] = '\0';
    printf("Client :  %s\n", buffer);

    // le proxy envoie le PASS au serveur
    write(sockServeurCOMftp ,buffer, strlen(buffer));
    ecode = read(sockServeurCOMftp, buffer, MAXBUFFERLEN-1);
    if (ecode == -1){
        perror("Problème lecture d'un socket");
        exit(2);
    }
    buffer[ecode] = '\0';
    printf("Serveur : %s\n",buffer);

    // le proxy envoie 230 au client et s'attend à recevoir le SYST du client
    write(descSockCOM, buffer, strlen(buffer));
    ecode = read(descSockCOM,buffer,MAXBUFFERLEN-1);
    if (ecode == -1){
        perror("Problème lecture d'un socket");
        exit(2);
    }
    buffer[ecode] = '\0';
    printf("Client : %s\n",buffer);

    // le proxy envoie le SYST au serveur
    write(sockServeurCOMftp ,buffer, strlen(buffer));
    ecode = read(sockServeurCOMftp,buffer,MAXBUFFERLEN-1);
    if (ecode == -1){
        perror("Problème lecture d'un socket");
        exit(2);
    }
    buffer[ecode]='\0';
    printf("Serveur : %s\n",buffer);

    // le proxy envoie 215 au client et le proxy recoit PASV
    write(descSockCOM, buffer, strlen(buffer));
    ecode = read(descSockCOM,buffer,MAXBUFFERLEN-1);
    if (ecode == -1){
        perror("Problème lecture d'un socket");
        exit(2);
    }
    buffer[ecode]='\0';
    printf("Client : %s\n",buffer);

    // Tant que le client n'a pas envoyé la commande "close", l'échange continue
    while (strncmp(buffer, "QUIT", 4) != 0){
      if (strncmp(buffer, "PASV", 4) == 0) {
          // Envoi de la commande PASV au serveur FTP
          write(sockServeurCOMftp, buffer, strlen(buffer));
          // Lecture de la réponse du serveur FTP (contenant l'adresse et le port)
          ecode = read(sockServeurCOMftp, buffer, MAXBUFFERLEN - 1);
          if (ecode == -1) {
              perror("Erreur lors de la lecture de la réponse PASV du serveur FTP");
              exit(2);
          }
          buffer[ecode] = '\0';
          printf("Serveur (PASV) : %s\n", buffer);

          // // Répondre au client la liste ----------------------------------- A NE PAS FAIRE : on ne souhaite pas afficher coté client
          // write(descSockCOM, buffer, strlen(buffer));
          // ecode=read(descSockCOM,buffer,MAXBUFFERLEN-1); // et l'envoie au client
          // if (ecode==-1){
          //     perror("Problème lecture d'un socket");
          //     exit(2);
          // }
          // buffer[ecode]='\0';
          // printf("Client : %s\n",buffer);

          // Extraction de l'adresse et du port à partir de la réponse PASV
          char clientAddr[MAXHOSTLEN];
          char clientPort[MAXPORTLEN];
          extraireInfosClient(buffer, clientAddr, clientPort);

          // Création d'une nouvelle connexion pour les données
          int descSockDON;
          ecode = connect2Server(clientAddr, clientPort, &descSockDON);
          if (ecode == -1) {
              perror("Erreur de connexion à la socket de données");
              exit(2);
          }

          // Envoi de la commande LIST au serveur FTP
          write(sockServeurCOMftp, "LIST\r\n", strlen("LIST\r\n"));

          // Lecture et affichage de la liste des fichiers du serveur
          while ((ecode = read(descSockDON, buffer, MAXBUFFERLEN - 1)) > 0) { // tant qu'il y a encore des lignes à écrire :
              buffer[ecode] = '\0';
              printf("%s", buffer);
          }

          // Fermeture de la connexion de données
          close(descSockDON);

          // Lecture de la réponse du serveur FTP après l'envoi de la commande LIST
          ecode = read(sockServeurCOMftp, buffer, MAXBUFFERLEN - 1);
          if (ecode == -1) {
              perror("Erreur lors de la lecture de la réponse LIST du serveur FTP");
              exit(2);
          }
          buffer[ecode] = '\0';
          printf("Serveur (LIST) : %s\n", buffer);

          // Envoi du 226 au client
          write(descSockCOM, buffer, strlen(buffer));
      }
    }
    // Si le client envoie 'close', le proxy envoie QUIT au serveur
    write(sockServeurCOMftp, buffer, strlen(buffer));
    ecode = read(sockServeurCOMftp, buffer, MAXBUFFERLEN-1);
    if (ecode == -1){
        perror("Il y a eu une erreur lors de la lecture d'une socket !");
        exit(2);
    }
    buffer[ecode] = '\0';
    printf("Serveur : %s\n", buffer);
    // Le proxy envoie au client le message du serveur (GOODBYE)
    write(descSockCOM, buffer, strlen(buffer));

    close(descSockCOM);
    close(sockServeurCOMftp);
}
